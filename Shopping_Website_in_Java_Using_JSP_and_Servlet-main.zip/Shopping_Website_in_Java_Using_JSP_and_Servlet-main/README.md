# Shopping Website in Java using JSP and Servlet

 This sample shows how to implement a simple E-commerce shopping website using JSP and Servlet
 
## Authors

- [@gururaj_koni](https://www.github.com/gururajkoni04) [@linkedin](https://www.linkedin.com/in/gururajkoni/)

## Screenshots
![App Screenshot](https://drive.google.com/uc?export=view&id=1NWsHbgcS4u1jzkb6o5xl8lbD5l5qeR9e)
![App Screenshot](https://drive.google.com/uc?export=view&id=126ykdq4ucwfECQ3IRga0qPLJbgZZUxeB)
![App Screenshot](https://drive.google.com/uc?export=view&id=1qbK3tDBFxFG4jg0X98mhw570KGsITW9r)
![App Screenshot](https://drive.google.com/uc?export=view&id=15sEen0DQEJLf17nz3x8Oz0F5L0313zeb)
