// 
// Decompiled by Procyon v0.5.36
// 

package classes;

public class Item
{
    public String id;
    public String name;
    public int price;
    
    public Item(final String a, final String b, final int c) {
        this.id = a;
        this.name = b;
        this.price = c;
    }
}